use crate::engine::Rang;

pub struct Player {
    pub name: String,
    pub colour: Rang,
}
